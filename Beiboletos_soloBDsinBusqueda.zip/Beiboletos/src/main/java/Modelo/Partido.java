/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author allen
 */
public class Partido {
    
    private int Equipo_1;
    private int Equipo_2;
    private String Lugar;
    private int Hora;
    private int Dia;
    private int Mes;

    public int getEquipo_1() {
        return Equipo_1;
    }

    public void setEquipo_1(int Equipo_1) {
        this.Equipo_1 = Equipo_1;
    }

    public int getEquipo_2() {
        return Equipo_2;
    }

    public void setEquipo_2(int Equipo_2) {
        this.Equipo_2 = Equipo_2;
    }

    public String getLugar() {
        return Lugar;
    }

    public void setLugar(String Lugar) {
        this.Lugar = Lugar;
    }

    public int getHora() {
        return Hora;
    }

    public void setHora(int Hora) {
        this.Hora = Hora;
    }

    public int getDia() {
        return Dia;
    }

    public void setDia(int Dia) {
        this.Dia = Dia;
    }

    public int getMes() {
        return Mes;
    }

    public void setMes(int Mes) {
        this.Mes = Mes;
    }
    
    

}
